Wornways demo activities

Made-up rides and runs on real roads in Mallorca, for trying Wornways without your own
activities. The routes were drawn along roads from OpenStreetMap data, (c) OpenStreetMap
contributors, available under the Open Database License (ODbL) 1.0:
https://opendatacommons.org/licenses/odbl/1-0/
The road data came from OpenMapTiles vector tiles served by OpenFreeMap.

The heights come from Terrain Tiles (https://registry.opendata.aws/terrain-tiles/):
SRTM terrain data courtesy of the U.S. Geological Survey, and ETOPO1 terrain data from
the U.S. National Oceanic and Atmospheric Administration.
